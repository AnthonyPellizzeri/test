
![](images/logo-Univ.png)


# Installation
Pour installer ce programme :  

- installer java 8
- décompresser la distribution binaire (bindist) dans un dossier d'installation
l'exécutable se trouve dans le fichier bin/app (linux ou macOs) ou bin/app.bat (Windows).

# Désinstallation
Pour désinstaller, il faut supprimer le dossier d'installation.
